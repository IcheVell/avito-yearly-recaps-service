DROP TABLE IF EXISTS conversation_participants;
DROP TABLE IF EXISTS conversations;
DROP TABLE IF EXISTS listing_views;
DROP TABLE IF EXISTS user_searches;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS deals;
DROP TABLE IF EXISTS user_sessions;
DROP TABLE IF EXISTS favorite_listings;
DROP TABLE IF EXISTS listings;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS user_achievements;
DROP TABLE IF EXISTS yearly_recaps;
DROP TABLE IF EXISTS achievements;
DROP TABLE IF EXISTS users;

DROP DOMAIN IF EXISTS non_empty_varchar_255;